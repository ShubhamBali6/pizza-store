const express = require('express');
const router = express.Router();
const Item = require('../models/item');

// List all items
router.get('/', async (req, res) => {
  try {
    const items = await Item.find();
    res.render('index', { items });
  } catch (err) {
    res.status(500).send(err);
  }
});

// Show form to add a new item
router.get('/new', (req, res) => {
  res.render('add-item');
});

// Create a new item
router.post('/', async (req, res) => {
  try {
    const newItem = new Item(req.body);
    await newItem.save();
    res.redirect('/items');
  } catch (err) {
    res.status(400).send(err);
  }
});

// Show form to edit an item
router.get('/:id/edit', async (req, res) => {
  try {
    const item = await Item.findById(req.params.id);
    res.render('edit-item', { item });
  } catch (err) {
    res.status(500).send(err);
  }
});

// Update an item
router.put('/:id', async (req, res) => {
  try {
    await Item.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.redirect('/items');
  } catch (err) {
    res.status(400).send(err);
  }
});

// Delete an item
router.delete('/:id/delete', async (req, res) => {
  try {
    await Item.findByIdAndDelete(req.params.id);
    res.redirect('/items');
  } catch (err) {
    res.status(500).send(err);
  }
});


module.exports = router;
