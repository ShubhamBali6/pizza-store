const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Middleware to parse JSON request bodies
app.use(bodyParser.json());

// In-memory database to store pizza items
let items = [];
let idCounter = 1;

// Create a new item
app.post('/items', (req, res) => {
  const item = {
    id: idCounter++,
    name: req.body.name,
    price: req.body.price,
  };
  items.push(item);
  res.status(201).send(item);
});

// Get all items
app.get('/items', (req, res) => {
  res.send(items);
});

// Get a specific item by ID
app.get('/items/:id', (req, res) => {
  const item = items.find(i => i.id == req.params.id);
  if (item) {
    res.send(item);
  } else {
    res.status(404).send({ message: 'Item not found' });
  }
});

// Update an existing item by ID
app.put('/items/:id', (req, res) => {
  const item = items.find(i => i.id == req.params.id);
  if (item) {
    item.name = req.body.name;
    item.price = req.body.price;
    res.send(item);
  } else {
    res.status(404).send({ message: 'Item not found' });
  }
});


// Delete an item by ID
app.delete('/items/:id', (req, res) => {
    const index = items.findIndex(i => i.id == req.params.id);
    if (index !== -1) {
      const deletedItem = items.splice(index, 1);
      res.send(deletedItem);
    } else {
      res.status(404).send({ message: 'Item not found' });
    }
  });
  
  // Start the server
  app.listen(port, () => {
    console.log(`Pizza store app listening at http://localhost:${port}`);
  });
